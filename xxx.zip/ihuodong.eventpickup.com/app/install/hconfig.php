<?php

/**
 * @version			$Id$
 * @create 			2012-04-21 11:04:10 By xjiujiu
 * @description     HongJuZi Framework
 * @copyRight 		Copyright (c) 2011-2012 http://www.xjiujiu.com.All right reserved
 */
defined('_HEXEC') or die('Restricted access!');

return array (
    'PAGE_STYLE' => 'bootstrap',  //分页风格
    'CUR_THEME' => 'ace'      //当前使用的模板
);

?>
