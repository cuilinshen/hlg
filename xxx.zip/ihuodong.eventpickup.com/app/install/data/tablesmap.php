<?php

/**
 * @version $Id$
 * @author xjiujiu <xjiujiu@foxmail.com>
 * @description HongJuZi Framework
 * @copyright Copyright (c) 2011-2012 http://www.xjiujiu.com.All right reserved
 */
defined('_HEXEC') or die('Restricted access!');

return array (
    0 => 'actor',
    1 => 'adv',
    2 => 'article',
    3 => 'category',
    4 => 'comment',
    5 => 'lang',
    6 => 'link',
    7 => 'linkeddata_actor_rights',
    8 => 'linkeddata_adv_lang',
    9 => 'linkeddata_article_category',
    10 => 'linkeddata_article_lang',
    11 => 'linkeddata_article_resource',
    12 => 'linkeddata_article_tags',
    13 => 'linkeddata_category_lang',
    14 => 'linkeddata_link_lang',
    15 => 'linkeddata_navmenu_lang',
    16 => 'linkeddata_tpl_mark',
    16 => 'linkeddata_website_lang',
    16 => 'theme',
    16 => 'contact',
    17 => 'log',
    18 => 'mark',
    19 => 'message',
    20 => 'modelmanager',
    21 => 'navmenu',
    22 => 'resource',
    23 => 'rights',
    24 => 'rss',
    25 => 'sharecfg',
    26 => 'sharesetting',
    27 => 'staticcfg',
    28 => 'tags',
    29 => 'tpl',
    30 => 'translate',
    31 => 'user',
    32 => 'website'
);
