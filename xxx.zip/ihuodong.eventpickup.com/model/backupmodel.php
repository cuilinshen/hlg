<?php 

/**
 * @version			$Id$
 * @create 			2012-5-2 9:37:08 By xjiujiu
 * @package 		app.admin
 * @subpackage 		model
 * @copyRight 		Copyright (c) 2011-2012 http://www.xjiujiu.com.All right reserved
 * HongJuZi Framework
 */
defined('_HEXEC') or die('Restricted access!');

/**
 * 数据库备份数据库操作层类 
 * 
 * @desc
 * 
 * @author 			xjiujiu <xjiujiu@foxmail.com>
 * @package 		app.admin.model
 * @since 			1.0.0
 */
class DbtoolModel extends HModel
{

    /**
     * 得到数据库备份的SQL语句 
     * 
     * @access public
     */
    public function getBackupDbSql()
    {
    }

}


?>
