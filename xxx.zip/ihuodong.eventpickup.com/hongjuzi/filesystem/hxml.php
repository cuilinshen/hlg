<?php

/**
 * @version			$Id: HXml.php 1859 2012-05-20 04:47:19Z xjiujiu $
 * @create 			2012-3-29 14:42:38 By xjiujiu
 * @package 	 	hongjuzi
 * @subpackage 		filesystem
 * @copyRight 		Copyright (c) 2011-2012 http://www.xjiujiu.com.All right reserved
 * HongJuZi Framework
 */
defined('HJZ_DIR') or die();

/**
 * XML操作工具类 
 * 
 * 对SimpleXml的封装 
 * 
 * @author 			xjiujiu <xjiujiu@foxmail.com>
 * @package 		hongjuzi.filesystem
 * @since 			1.0.0
 */
class HXml
{

    /**
     * 构造函数 
     * 
     * 初始化变量 
     * 
     * @access public
     * @return void
     * @exception none
     */
	public function __construct()
	{
	}

}
?>
