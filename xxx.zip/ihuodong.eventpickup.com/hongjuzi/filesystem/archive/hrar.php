<?php

defined('HJZ_DIR') or die();

/**
 * @author �ž�
 * @since 			1.0.0
 * @created 17-����-2012 18:18:45
 */
class HRar
{

	function HRar()
	{
	}



}
?>
