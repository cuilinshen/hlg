<?php

defined('HJZ_DIR') or die();

/**
 * @author 九九
 * @since 			1.0.0
 * @created 25-二月-2012 13:08:37
 */
class HDownload
{

	function HDownload()
	{
	}



}
?>
