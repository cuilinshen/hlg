<?php 
/**
 * @version         $Id$
 * @create          2012-5-1 22:27:14 By xjiujiu
 * @description     HongJuZi Framework
 * @copyRight       Copyright (c) 2011-2012 http://www.xjiujiu.com.All right reserved
 */
defined('_HEXEC') or die('Restricted access!');

return array (
  '语言标识' => NULL,
  '内容简介' => 'Content abstract',
  '所属分类' => NULL,
  '标识' => NULL,
  '创建时间' => NULL,
  '语言' => NULL,
  '阅读数' => NULL,
  '图片' => NULL,
  '标题' => NULL,
  'ID' => NULL,
  '排序' => NULL,
  '综合分类' => NULL,
  '文章' => NULL,
  '没有图片' => NULL,
  '内容' => NULL,
  '下一页' => NULL,
  '上一页' => NULL,
  '固定菜单' => NULL,
  '固定顶端' => NULL,
  '更换风格' => NULL,
  '系统用户' => NULL,
  '数据库工具' => NULL,
  '写邮件' => NULL,
  '用户' => NULL,
  '安全退出' => NULL,
  '个人设置' => NULL,
  '网站设置' => NULL,
  '您好' => NULL,
  '退出' => NULL,
  '去网站' => NULL,
  '后台管理平台' => NULL,
); 

?>
