<?php 
/*请设置“http://39.98.37.117/”的配置信息*/

return array (
  'DEF_APP' => 'cms',
  'DATABASE' => 
  array (
    'tablePrefix' => 'xxx_',
    'dbHost' => 'xxx.xxx.xxx.xxx',
    'dbPort' => '3306',
    'dbType' => 'mysql',
    'dbDriver' => 'mysqli',
    'dbCharset' => 'utf8',
    'dbName' => 'xxxx',
    'dbUserName' => 'xxxxx',
    'dbUserPassword' => 'xxxx',
  ),
  'STATIC_URL' => 'http://39.98.37.117/',
  'CDN_URL' => 'http://39.98.37.117/vendor/',
  'SALT' => '1a265091325540fb804f9733f8349565',
  'TIME_ZONE' => 'Asia/Shanghai',
  'RES_DIR' => 'static/uploadfiles/sites/39-98-37-117/'
); ?>
