<?php 
/*请设置“http://ihuodong.eventpickup.com/”的配置信息*/

return array (
  'DEF_APP' => 'cms',
  'DATABASE' => 
  array (
    'tablePrefix' => 'hjz_',
    'dbHost' => 'localhost',
    'dbPort' => '3306',
    'dbType' => 'mysql',
    'dbDriver' => 'mysqli',
    'dbCharset' => 'utf8',
    'dbName' => 'ydt_huodong',
    'dbUserName' => 'ydt_huodong',
    'dbUserPassword' => '8BFDDxeXWLLdDtJa',
  ),
  'STATIC_URL' => 'http://ihuodong.eventpickup.com/',
  'CDN_URL' => 'http://ihuodong.eventpickup.com/vendor/',
  'SALT' => 'e511782a26034722a95c10bed7fe5e94',
  'TIME_ZONE' => 'Asia/Shanghai',
  'RES_DIR' => 'static/uploadfiles/sites/ihuodong-eventpickup-com/'
); ?>
