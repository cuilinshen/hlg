<?php 
/*请设置“http://www.huodong.fun/”的配置信息*/

return array (
  'DEF_APP' => 'cms',
  'DATABASE' => 
  array (
    'tablePrefix' => 'hjz_',
    'dbHost' => 'localhost',
    'dbPort' => '3306',
    'dbType' => 'mysql',
    'dbDriver' => 'mysqli',
    'dbCharset' => 'utf8',
    'dbName' => 'ydt_huodong',
    'dbUserName' => 'root',
    'dbUserPassword' => 'L2mA5KeXtrkxXaWG',
  ),
  'STATIC_URL' => 'http://www.huodong.fun/',
  'CDN_URL' => 'http://www.huodong.fun/vendor/',
  'SALT' => '74dfb44ae1be49d78753f763cef5a681',
  'TIME_ZONE' => 'Asia/Shanghai',
  'RES_DIR' => 'static/uploadfiles/sites/www-huodong-fun/'
); ?>
