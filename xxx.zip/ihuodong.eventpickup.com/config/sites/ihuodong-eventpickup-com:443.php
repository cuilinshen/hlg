<?php 
/*请设置“http://ihuodong.eventpickup.com:443/”的配置信息*/

return array (
  'DEF_APP' => 'cms',
  'DATABASE' => 
  array (
    'tablePrefix' => 'xxx_',
    'dbHost' => 'xxx.xxx.xxx.xxx',
    'dbPort' => '3306',
    'dbType' => 'mysql',
    'dbDriver' => 'mysqli',
    'dbCharset' => 'utf8',
    'dbName' => 'xxxx',
    'dbUserName' => 'xxxxx',
    'dbUserPassword' => 'xxxx',
  ),
  'STATIC_URL' => 'http://ihuodong.eventpickup.com:443/',
  'CDN_URL' => 'http://ihuodong.eventpickup.com:443/vendor/',
  'SALT' => '5d825f339a724111a7360df891097f5d',
  'TIME_ZONE' => 'Asia/Shanghai',
  'RES_DIR' => 'static/uploadfiles/sites/ihuodong-eventpickup-com:443/'
); ?>
