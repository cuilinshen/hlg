<?php

/**
 * @version			$Id$
 * @create 			2012-04-21 11:04:10 By xjiujiu
 * @description    HongJuZi Framework 这是一个应用配置的模板文件，如果应用于的对应配置有不一样
 *                  请复制这个文件到您的应用下面，如：cms/hconfig.php 【注：不能改文件名】
 * @copyRight 		Copyright (c) 2011-2012 http://www.xjiujiu.com.All right reserved
 */
defined('_HEXEC') or die('Restricted access!');

return array (
  'PAGE_STYLE' => 'bootstrap',  //分页风格
  'CUR_THEME' => 'default'      //当前使用的模板
);

?>
