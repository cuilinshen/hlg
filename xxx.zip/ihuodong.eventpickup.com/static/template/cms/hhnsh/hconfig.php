<?php 

return array(
    'name' => '怀化农商行',               //*
    'identifier' => 'hhnsh',          //*
    'description' => '怀化农商行 默认主题',   //*
    'image_path' => 'images/index.png', //*
    'tag' => 'all',                     //*
    'publisher' => '红橘子科技',
    'website' => 'http://www.hongjuzi.net'
);

?>
