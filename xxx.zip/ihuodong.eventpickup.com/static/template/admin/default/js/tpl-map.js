
/**
 * @version $Id$
 * @author xjiujiu <xjiujiu@foxmail.com>
 * @description HongJuZi Framework
 * @copyright Copyright (c) 2011-2012 http://www.xjiujiu.com.All right reserved
 */
var TplMap  = {
    TableGrid: '<table id="grid-{t}" class="table table-condensed table-hover table-striped" data-selection="true" data-multi-select="true" data-row-select="true" data-keep-selection="true">'
    + '<thead>'
    + '<tr>{thead}'
    + '</tr>'
    + '</thead>'
    + '<tbody>{tbody}</tbody></table>'
};
