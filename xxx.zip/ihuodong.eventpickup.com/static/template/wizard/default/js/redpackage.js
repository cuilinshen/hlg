HHJsLib.register({
    init: function() {
        this.bindRedPackageRank();
    },
    bindRedPackageRank: function() {
        $('.chart').easyPieChart({ animate: 2000 }); 
    }
});